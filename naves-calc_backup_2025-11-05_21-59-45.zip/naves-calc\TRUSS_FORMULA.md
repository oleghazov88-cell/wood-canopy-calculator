# 🏗️ Формула устройства фермы

## 🎯 Описание

Математическая формула и алгоритм построения фермы в 3D конфигураторе навеса. Ферма строится по классической треугольной схеме с дополнительными элементами жесткости.

## 📐 Математическая модель

### Основные параметры фермы:

```javascript
const trussParams = {
    span: width,                    // Пролет фермы (ширина навеса)
    rise: roofHeight,               // Подъем фермы (высота конька)
    sectionSize: trussDimensions,   // Размеры сечения элементов фермы
    bottomChordHeight: height + beamDimensions.height / 2  // Высота нижнего пояса
};
```

### Координаты узлов фермы:

```javascript
const nodes = {
    leftBottom: { x: -L/2, y: bottomChordHeight },      // Левый нижний узел
    rightBottom: { x: L/2, y: bottomChordHeight },      // Правый нижний узел
    ridge: { x: 0, y: bottomChordHeight + H },          // Коньковый узел
    leftQuarter: { x: -L/4, y: bottomChordHeight },     // Левый четвертной узел
    rightQuarter: { x: L/4, y: bottomChordHeight },     // Правый четвертной узел
    center: { x: 0, y: bottomChordHeight }              // Центральный нижний узел
};

// Точки для торцевого соединения стропильных ног
const leftRafterEnd = { x: -beamSize.width/2, y: bottomChordHeight + H };
const rightRafterEnd = { x: beamSize.width/2, y: bottomChordHeight + H };
```

## 🔧 Формулы расчета

### 1. Основные размеры:
- **L = span** - пролет фермы (ширина навеса)
- **H = Math.max(rise, 0.1)** - подъем фермы (минимум 0.1 м)
- **bottomChordHeight = height + beamDimensions.height / 2** - высота нижнего пояса

### 2. Координаты узлов:

#### Нижний пояс:
- **Левый узел:** `x = -L/2, y = bottomChordHeight`
- **Правый узел:** `x = L/2, y = bottomChordHeight`
- **Центральный узел:** `x = 0, y = bottomChordHeight`

#### Верхний пояс (конек):
- **Коньковый узел:** `x = 0, y = bottomChordHeight + H`
- **Левый конец стропильной ноги:** `x = -beamSize.width/2, y = bottomChordHeight + H`
- **Правый конец стропильной ноги:** `x = beamSize.width/2, y = bottomChordHeight + H`

#### Четвертные узлы:
- **Левый четвертной:** `x = -L/4, y = bottomChordHeight`
- **Правый четвертной:** `x = L/4, y = bottomChordHeight`

### 3. Элементы фермы:

#### Нижний пояс:
```
leftBottom → rightBottom
```

#### Стропильные ноги:
```
leftBottom → leftRafterEnd
rightRafterEnd → rightBottom
```

#### Центральная стойка:
```
center → ridge
```

#### Раскосы:
```
leftQuarter → leftRafterEnd
rightQuarter → rightRafterEnd
```

#### Конек:
```
ridge (сплошной элемент длиной 0 м)
```

## 🏗️ Алгоритм построения

### 1. Создание узлов:
```javascript
const nodes = {
    leftBottom: { x: -L/2, y: bottomChordHeight },
    rightBottom: { x: L/2, y: bottomChordHeight },
    ridge: { x: 0, y: bottomChordHeight + H },
    leftQuarter: { x: -L/4, y: bottomChordHeight },
    rightQuarter: { x: L/4, y: bottomChordHeight },
    center: { x: 0, y: bottomChordHeight }
};
```

### 2. Создание элементов:
```javascript
// Нижний пояс
trussGroup.add(this.createBeam(nodes.leftBottom, nodes.rightBottom, beamSize, woodMaterial));

// Стропильные ноги (торцевое соединение)
trussGroup.add(this.createBeam(nodes.leftBottom, leftRafterEnd, beamSize, woodMaterial));
trussGroup.add(this.createBeam(rightRafterEnd, nodes.rightBottom, beamSize, woodMaterial));

// Центральная стойка
trussGroup.add(this.createBeam(nodes.center, nodes.ridge, beamSize, woodMaterial));

// Раскосы
trussGroup.add(this.createBeam(nodes.leftQuarter, leftRafterEnd, beamSize, woodMaterial));
trussGroup.add(this.createBeam(nodes.rightQuarter, rightRafterEnd, beamSize, woodMaterial));

// Конек (длиной 0 м)
const ridgeBeam = this.createRidgeBeam(nodes.ridge, beamSize, woodMaterial);
trussGroup.add(ridgeBeam);
```

### 3. Создание балки между узлами:
```javascript
createBeam(startNode, endNode, sectionSize, material) {
    const dx = endNode.x - startNode.x;
    const dy = endNode.y - startNode.y;
    const length = Math.sqrt(dx * dx + dy * dy);
    
    const beamGeometry = new THREE.BoxGeometry(length, sectionSize.height, sectionSize.width);
    const beam = new THREE.Mesh(beamGeometry, material);
    
    const centerX = (startNode.x + endNode.x) / 2;
    const centerY = (startNode.y + endNode.y) / 2;
    beam.position.set(centerX, centerY, 0);
    
    const angle = Math.atan2(dy, dx);
    beam.rotation.z = angle;
    
    return beam;
}
```

### 4. Создание конька:
```javascript
createRidgeBeam(ridgeNode, sectionSize, material) {
    const ridgeLength = 0; // Длина конька (0 см)
    const ridgeGeometry = new THREE.BoxGeometry(ridgeLength, sectionSize.height, sectionSize.width);
    const ridgeBeam = new THREE.Mesh(ridgeGeometry, material);
    
    ridgeBeam.position.set(ridgeNode.x, ridgeNode.y, 0);
    ridgeBeam.castShadow = true;
    ridgeBeam.receiveShadow = true;
    
    return ridgeBeam;
}
```

## 📊 Геометрические характеристики

### Углы наклона стропильных ног:
- **Левый скат:** `α = arctan(H / (L/2)) = arctan(2H/L)`
- **Правый скат:** `α = arctan(H / (L/2)) = arctan(2H/L)`

### Длины элементов:
- **Нижний пояс:** `L`
- **Стропильные ноги:** `√((L/2)² + H²)`
- **Центральная стойка:** `H`
- **Раскосы:** `√((L/4)² + H²)`
- **Конек:** `0 м` (фиксированная длина)

### Высоты узлов:
- **Нижние узлы:** `bottomChordHeight`
- **Коньковый узел:** `bottomChordHeight + H`

## 🎯 Схема фермы

```
                    leftRafterEnd              rightRafterEnd
                    (-beamSize.width/2,        (beamSize.width/2,
                     bottomChordHeight + H)     bottomChordHeight + H)
                        /|\                        /|\
                       / | \                      / | \
                      /  |  \                    /  |  \
                     /   |   \                  /   |   \
                    /    |    \                /    |    \
                   /     |     \              /     |     \
                  /      |      \            /      |      \
                 /       |       \          /       |       \
                /        |        \        /        |        \
               /         |         \      /         |         \
              /          |          \    /          |          \
             /           |           \  /           |           \
            /            |            \/            |            \
           /             |            /\            |             \
          /              |          /    \          |              \
         /               |        /        \        |               \
        /                |      /            \      |                \
       /                 |    /                \    |                 \
      /                  |  /                    \  |                  \
     /                   |/                        \|                   \
    /                    |                          |                    \
   /                     |                          |                     \
  /                      |                          |                      \
 /                       |                          |                       \
/                        |                          |                        \
leftQuarter              center              rightQuarter
(-L/4, bottomChordHeight) (0, bottomChordHeight) (L/4, bottomChordHeight)
         \                        |                        /
          \                       |                       /
           \                      |                      /
            \                     |                     /
             \                    |                    /
              \                   |                   /
               \                  |                  /
                \                 |                 /
                 \                |                /
                  \               |               /
                   \              |              /
                    \             |             /
                     \            |            /
                      \           |           /
                       \          |          /
                        \         |         /
                         \        |        /
                          \       |       /
                           \      |      /
                            \     |     /
                             \    |    /
                              \   |   /
                               \  |  /
                                \ | /
                                 \|/
leftBottom                    rightBottom
(-L/2, bottomChordHeight)     (L/2, bottomChordHeight)
```

## ⚡ Преимущества конструкции

### Прочность и жесткость:
- **Треугольная схема** - обеспечивает геометрическую неизменяемость
- **Центральная стойка** - воспринимает вертикальные нагрузки
- **Раскосы** - обеспечивают поперечную жесткость
- **Торцевое соединение** - стропильные ноги смыкаются торцами, образуя треугольник
- **Точечный конек** - создает жесткий узел в вершине без дополнительного материала

### Экономичность:
- **Минимальное количество элементов** - 6 основных элементов
- **Рациональное использование материала** - все элементы работают
- **Простота изготовления** - стандартные соединения

### Универсальность:
- **Адаптивность** - размеры изменяются в зависимости от параметров
- **Масштабируемость** - работает для разных пролетов
- **Совместимость** - интегрируется с системой навеса

## 🎯 Результат

Ферма строится по классической треугольной схеме с:
- ✅ **6 основными элементами** - нижний пояс, 2 стропильные ноги, центральная стойка, 2 раскоса
- ✅ **Торцевым соединением** - стропильные ноги смыкаются торцами, образуя треугольник
- ✅ **Точечным коньком** - жесткий узел в вершине без дополнительного материала
- ✅ **Рациональной геометрией** - все элементы работают на нагрузку
- ✅ **Адаптивными размерами** - изменяются в зависимости от параметров навеса
- ✅ **Прочной конструкцией** - обеспечивает несущую способность

**Ферма построена по классической треугольной схеме с торцевым соединением стропильных ног!** 🎯
