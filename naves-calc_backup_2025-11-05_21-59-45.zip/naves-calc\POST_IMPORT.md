# 📐 Импорт столбов GLB - УДАЛЕНО

## ⚠️ ВАЖНО: Эта функция была удалена

Импорт столбов в формате GLB был удален из проекта. Теперь используются только **стандартные геометрические формы** (BoxGeometry) для всех типов столбов.

## 🎯 Описание (устаревшее)

~~Система импорта столбов в формате GLB с правильной точкой привязки по осям стандартных столбов. Столбы загружаются опционально в зависимости от выбора в меню "Столбы".~~

## 🏗️ Структура файлов

```
stolb/
├── S1.glb          # Столб типа 1 (var-2)
├── S2.glb          # Столб типа 2 (var-3)
├── S3.glb          # Столб типа 3 (var-4)
├── S4.glb          # Столб типа 4 (var-5)
├── S5.glb          # Столб типа 5 (var-6)
└── S6.glb          # Столб типа 6 (var-7)
```

## 🔧 Технические детали

### Алгоритм загрузки

```javascript
async loadPostGLB(postType) {
    if (postType === 'var-1') {
        return null; // Стандартный столб
    }
    
    // Проверяем кэш
    if (this.glbCache[postType]) {
        return this.glbCache[postType];
    }
    
    const glbFile = `../stolb/S${postType.replace('var-', '')}.glb`;
    
    return new Promise((resolve, reject) => {
        const loader = new THREE.GLTFLoader();
        loader.load(
            glbFile,
            (gltf) => {
                const model = gltf.scene;
                model.scale.set(1, 1, 1);
                model.castShadow = true;
                model.receiveShadow = true;
                
                // Сохраняем в кэш
                this.glbCache[postType] = model;
                resolve(model);
            },
            (progress) => {
                console.log('Загрузка столба:', (progress.loaded / progress.total * 100) + '%');
            },
            (error) => {
                console.error('Ошибка загрузки столба:', error);
                resolve(null); // Возвращаем null при ошибке
            }
        );
    });
}
```

### Функция создания столбов

```javascript
async createPosts(length, width, height, woodMaterial, metalMaterial, postType, postMaterial) {
    const postSpacing = this.currentPostSpacing;
    const postsAlongLength = Math.ceil(length / postSpacing) + 1;
    const postDimensions = this.getPostDimensions(postMaterial);
    
    // Загружаем GLB модель столба
    const glbModel = await this.loadPostGLB(postType);
    
    // Создаем кэшированную геометрию для стандартных столбов
    const postGeometryKey = `post_${postDimensions.width}_${height}_${postDimensions.height}`;
    const postGeometry = this.getCachedGeometry(postGeometryKey, () => {
        return new THREE.BoxGeometry(postDimensions.width, height, postDimensions.height);
    });
    
    for (let i = 0; i < postsAlongLength; i++) {
        const z = -length/2 + (i * length / (postsAlongLength - 1));
        
        // Левый столб
        if (glbModel) {
            // Используем GLB модель с масштабированием по материалу
            const leftPost = glbModel.clone();
            leftPost.position.set(-width/2, height/2, z); // Позиционируем по центру как стандартный столб
            
            // Масштабируем GLB модель в соответствии с материалом столба и высотой
            const scaleX = postDimensions.width / 0.15; // Базовый размер 150x150
            const scaleZ = postDimensions.height / 0.15;
            const scaleY = height / 3.0; // Базовая высота GLB модели 3 метра
            leftPost.scale.set(scaleX, scaleY, scaleZ); // Масштабируем по всем осям
            
            leftPost.castShadow = true;
            leftPost.receiveShadow = true;
            this.canopyGroup.add(leftPost);
        } else {
            // Используем кэшированную геометрию
            const leftPost = new THREE.Mesh(postGeometry, woodMaterial);
            leftPost.position.set(-width/2, height/2, z);
            leftPost.castShadow = true;
            leftPost.receiveShadow = true;
            this.canopyGroup.add(leftPost);
        }
        
        // Правый столб
        if (glbModel) {
            // Используем GLB модель с масштабированием по материалу
            const rightPost = glbModel.clone();
            rightPost.position.set(width/2, height/2, z); // Позиционируем по центру как стандартный столб
            
            // Масштабируем GLB модель в соответствии с материалом столба и высотой
            const scaleX = postDimensions.width / 0.15; // Базовый размер 150x150
            const scaleZ = postDimensions.height / 0.15;
            const scaleY = height / 3.0; // Базовая высота GLB модели 3 метра
            rightPost.scale.set(scaleX, scaleY, scaleZ); // Масштабируем по всем осям
            
            rightPost.castShadow = true;
            rightPost.receiveShadow = true;
            this.canopyGroup.add(rightPost);
        } else {
            // Используем кэшированную геометрию
            const rightPost = new THREE.Mesh(postGeometry, woodMaterial);
            rightPost.position.set(width/2, height/2, z);
            rightPost.castShadow = true;
            rightPost.receiveShadow = true;
            this.canopyGroup.add(rightPost);
        }
    }
}
```

## 📊 Маппинг типов столбов

| Кнопка в UI | postType | GLB файл | Описание |
|-------------|----------|----------|----------|
| Столб 1 | var-1 | - | Стандартный столб (BoxGeometry) |
| Столб 2 | var-2 | S1.glb | GLB модель столба 1 |
| Столб 3 | var-3 | S2.glb | GLB модель столба 2 |
| Столб 4 | var-4 | S3.glb | GLB модель столба 3 |
| Столб 5 | var-5 | S4.glb | GLB модель столба 4 |
| Столб 6 | var-6 | S5.glb | GLB модель столба 5 |
| Столб 7 | var-7 | S6.glb | GLB модель столба 6 |

## 🎮 Использование

### Для пользователей:
1. **Выберите тип столба** в меню "Столбы"
2. **Стандартный столб** (var-1) - использует BoxGeometry
3. **GLB столбы** (var-2 до var-7) - загружают 3D модели из файлов
4. **Материал столбов** влияет на масштабирование GLB моделей
5. **Высота столбов** регулируется бегунком и влияет на масштабирование по Y

### Для разработчиков:
1. **Кэширование** - GLB модели кэшируются для производительности
2. **Масштабирование** - автоматическое масштабирование по материалу и высоте
3. **Позиционирование** - точная привязка по осям стандартных столбов
4. **Fallback** - при ошибке загрузки используется стандартный столб

## ⚡ Преимущества

### Правильная точка привязки
- **Точное позиционирование** - GLB столбы позиционируются по тем же осям, что и стандартные
- **Совместимость** - все столбы имеют одинаковую точку привязки
- **Визуальная точность** - 3D модель соответствует реальной конструкции

### Адаптивное масштабирование
- **По материалу** - размеры сечения адаптируются к выбранному материалу
- **По высоте** - высота регулируется бегунком "Высота столбов"
- **Пропорциональность** - сохраняются пропорции GLB модели

### Производительность
- **Кэширование** - GLB модели загружаются один раз и кэшируются
- **Оптимизация** - тени и материалы настраиваются автоматически
- **Fallback** - при ошибке загрузки используется стандартная геометрия

## 🔄 Логика работы

### 1. Выбор типа столба
- Пользователь выбирает тип столба в меню
- Система определяет, нужен ли GLB файл

### 2. Загрузка модели
- Если postType !== 'var-1', загружается GLB файл
- Модель кэшируется для повторного использования
- При ошибке возвращается null

### 3. Создание столбов
- Для каждого столба проверяется наличие GLB модели
- Если есть GLB модель - используется она с масштабированием
- Если нет GLB модели - используется стандартная BoxGeometry

### 4. Масштабирование
- **X и Z оси** - масштабируются по размерам материала столба
- **Y ось** - масштабируется по высоте из бегунка
- **Базовые размеры** - 150x150 мм для сечения, 3 метра для высоты

## 🎯 Результат

После импорта столбы:
- ✅ **Правильно позиционированы** по осям стандартных столбов
- ✅ **Корректно масштабированы** по материалу и высоте
- ✅ **Опционально загружаются** в зависимости от выбора в меню
- ✅ **Кэшируются** для улучшения производительности
- ✅ **Имеют fallback** на стандартные столбы при ошибках

**Столбы теперь импортируются с правильной точкой привязки по осям стандартных столбов!** 🎯
