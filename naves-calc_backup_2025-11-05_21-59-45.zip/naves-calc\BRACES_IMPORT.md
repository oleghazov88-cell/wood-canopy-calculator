# 🔧 Импорт раскосов в 3D калькулятор навесов

## 📋 Обзор

Калькулятор навесов теперь поддерживает импорт GLB моделей раскосов (подкосов) из папки `raskos`, что позволяет использовать различные типы раскосов в 3D модели.

## 📁 Доступные модели раскосов

В папке `raskos` доступны следующие GLB модели:

- **r1.glb** - Раскос тип 1 (Стандартный)
- **r2.glb** - Раскос тип 2
- **r3.glb** - Раскос тип 3  
- **r4.glb** - Раскос тип 4

## 🎯 Функциональность

### 1. **Загрузка GLB моделей раскосов**
- **Кэширование** - модели загружаются один раз и кэшируются
- **Обработка ошибок** - при ошибке загрузки используется стандартный раскос
- **Прогресс загрузки** - отображение прогресса в консоли

### 2. **Интеграция в 3D модель**
- **Позиционирование под балками** - раскосы размещаются под продольными балками слева и справа от столбов
- **Вертикальное размещение** - раскосы поворачиваются на 90 градусов для вертикального размещения
- **Тени и освещение** - поддержка теней и реалистичного освещения

### 3. **Интерфейс выбора**
- **Селект типа раскосов** в форме калькулятора
- **4 варианта** на выбор (Стандартный + 3 GLB модели)
- **Автоматическое обновление** 3D модели при изменении

## 🔧 Технические детали

### Загрузка GLB моделей

```javascript
// Функция загрузки GLB модели раскоса
async loadBraceGLB(braceType) {
    if (braceType === 'var-1') {
        return null; // Стандартный раскос
    }
    
    const glbFile = `../raskos/r${braceType.replace('var-', '')}.glb`;
    
    return new Promise((resolve, reject) => {
        const loader = new THREE.GLTFLoader();
        loader.load(glbFile, (gltf) => {
            const model = gltf.scene;
            model.scale.set(1, 1, 1);
            model.castShadow = true;
            model.receiveShadow = true;
            resolve(model);
        });
    });
}
```

### Создание раскосов под балками

```javascript
// Создание раскосов под балками с GLB моделями
async createBeamBraces(length, width, height, woodMaterial, frontExtension, backExtension, postMaterial, braceType) {
    const postSpacing = this.currentPostSpacing;
    const postsAlongLength = Math.ceil(length / postSpacing) + 1;
    
    // Загружаем GLB модель раскоса
    const glbModel = await this.loadBraceGLB(braceType);
    
    for (let i = 0; i < postsAlongLength; i++) {
        const z = -length/2 + (i * length / (postsAlongLength - 1));
        
        if (glbModel) {
            // Левый раскос (под левой балкой)
            const leftBrace = glbModel.clone();
            leftBrace.position.set(-width/2, height/2, z);
            leftBrace.rotation.z = Math.PI / 2; // Поворот на 90 градусов
            this.canopyGroup.add(leftBrace);
            
            // Правый раскос (под правой балкой)
            const rightBrace = glbModel.clone();
            rightBrace.position.set(width/2, height/2, z);
            rightBrace.rotation.z = Math.PI / 2; // Поворот на 90 градусов
            this.canopyGroup.add(rightBrace);
        } else {
            // Используем стандартные балки
            const beamDimensions = this.getPostDimensions(postMaterial);
            const braceGeometry = new THREE.BoxGeometry(beamDimensions.width, height/2, beamDimensions.height);
            
            const leftBrace = new THREE.Mesh(braceGeometry, woodMaterial);
            leftBrace.position.set(-width/2, height/4, z);
            this.canopyGroup.add(leftBrace);
            
            const rightBrace = new THREE.Mesh(braceGeometry, woodMaterial);
            rightBrace.position.set(width/2, height/4, z);
            this.canopyGroup.add(rightBrace);
        }
    }
}
```

### HTML интерфейс

```html
<div class="nc-field">
    <label class="nc-field__label">Тип раскосов</label>
    <select class="nc-field__input" id="braceType">
        <option value="var-1" selected>Стандартный</option>
        <option value="var-2">Раскос тип 2</option>
        <option value="var-3">Раскос тип 3</option>
        <option value="var-4">Раскос тип 4</option>
    </select>
</div>
```

## 🎮 Использование

### Для пользователей:
1. **Откройте калькулятор** навесов
2. **Найдите секцию** "Тип раскосов" в форме
3. **Выберите тип** раскоса из выпадающего списка
4. **Наблюдайте** как 3D модель обновляется с новыми раскосами

### Для разработчиков:
1. **Добавьте новые GLB файлы** в папку `raskos`
2. **Обновите селект** в HTML с новыми опциями
3. **Модели автоматически** загрузятся и будут использоваться

## 📊 Структура файлов

```
raskos/
├── r1.glb          # Раскос тип 1 (Стандартный)
├── r2.glb          # Раскос тип 2
├── r3.glb          # Раскос тип 3
├── r4.glb          # Раскос тип 4
├── 1 (1).webp      # Превью изображения
├── 2 (1).webp
├── 3 (1).webp
├── 4 (1).webp
└── ...
```

## 🔄 Процесс работы

### 1. **Инициализация**
- Калькулятор загружается с стандартными раскосами
- GLB модели загружаются по требованию

### 2. **Выбор типа**
- Пользователь выбирает тип раскоса в селекте
- Срабатывает обработчик события `change`

### 3. **Обновление модели**
- Загружается соответствующая GLB модель
- Раскосы размещаются под балками слева и справа от столбов
- 3D модель пересоздается с новыми раскосами
- Обновляется спецификация

### 4. **Кэширование**
- Загруженные модели сохраняются в кэше
- При повторном выборе модель берется из кэша

## ⚡ Оптимизация производительности

### Кэширование
- **GLB модели** кэшируются после первой загрузки
- **Избежание повторных загрузок** одного и того же файла
- **Умное освобождение памяти** при смене модели

### Асинхронная загрузка
- **Неблокирующая загрузка** GLB файлов
- **Показ индикатора загрузки** во время обновления
- **Graceful fallback** на стандартные раскосы при ошибках

## 🐛 Обработка ошибок

### Сценарии ошибок:
1. **Файл не найден** - используется стандартный раскос
2. **Ошибка загрузки** - используется стандартный раскос
3. **Некорректный GLB** - используется стандартный раскос

### Логирование:
```javascript
console.log('Загрузка раскоса:', (progress.loaded / progress.total * 100) + '%');
console.error('Ошибка загрузки раскоса:', error);
```

## 🔮 Планы развития

### Краткосрочные:
- [ ] **Превью изображения** для каждого типа раскоса
- [ ] **Анимация загрузки** GLB моделей
- [ ] **Валидация GLB файлов** при загрузке

### Долгосрочные:
- [ ] **Больше типов раскосов** (r5.glb, r6.glb, etc.)
- [ ] **Настраиваемые параметры** раскосов
- [ ] **Физическая симуляция** нагрузки на раскосы

## 📚 Дополнительные ресурсы

- [Three.js GLTFLoader](https://threejs.org/docs/#examples/en/loaders/GLTFLoader)
- [GLB File Format](https://www.khronos.org/gltf/)
- [3D Model Optimization](https://threejs.org/docs/#manual/en/introduction/Performance-tips)

---

**Версия:** 1.0  
**Дата:** 2024  
**Автор:** AI Assistant  
**Статус:** ✅ Готово к продакшену
